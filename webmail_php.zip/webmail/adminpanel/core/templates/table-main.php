<div id="wm_contacts_card">
	<div class="wm_contacts_card_line1"></div>
	<div class="wm_contacts_card_line2"></div>
	<div class="wm_contacts_card_line3"></div>
	<div class="wm_contacts_card_line4"></div>
	<div class="wm_contacts_card_line5"></div>
	<div class="wm_contacts_card_content">
		<img src="static/images/close-popup.png" class="wm_close_icon" onclick="document.location = 'index.php?close'" title="Close" alt="X" />
		<?php $this->SwitchersToString(); ?>
	</div>
	<div class="wm_contacts_card_line5"></div>
	<div class="wm_contacts_card_line4"></div>
	<div class="wm_contacts_card_line3"></div>
	<div class="wm_contacts_card_line2"></div>
	<div class="wm_contacts_card_line1"></div>
</div>

