<?php $this->WriteTabs(); ?>

<div class="wm_settings">
	<div class="wm_settings_row"><!--wm_settings_row_without_menu-->
		<div id="settings_nav" class="wm_settings_nav" style="height: auto;">

<?php $this->WriteMenu(); ?>

		</div>
		<div class="wm_settings_cont" style="height: auto;">
			<div class="wm_contacts" id="main_contacts">

			<?php $this->WriteMain(); ?>

			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>